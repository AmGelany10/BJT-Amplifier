We simulate the two schematic:
but the OPAMP Schematic we simulate it in tina
because pspice has constraint in the number of nodes(75)